<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "comprasdfernandez";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM compras";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    $codTable = "<table><tr><th>N° OC</th><th>Fecha</th><th>Cod. Articulo</th><th>Detalle</th><th>Cantidad</th><th>Acciones</th></tr>";
    while($row = $result->fetch_assoc()) {
        $codTable .= "<tr><th>". $row["orden"] ."</th><th>" 
        . $row["fecha"]. "</th><th>" 
        . $row["codigoArticulo"]. "</th><th>" 
        . $row["descripcionArticulo"]. "</th><th>" 
        . $row["cantidad"]. " (unidades) </th>"
        . "<th>
            <div class='btn-group'>
                <button id=". $row["orden"] ." onclick='GetDataOC( ". $row["orden"] .")' type='button' name='update' value=".  $row["orden"]  ." class='btn btn-warning'>Actualizar</button>
             <button id=". $row["orden"] ." onclick='DeleteOC(". $row["orden"] .")' type='button' name='update' value=".  $row["orden"]  ."type='button' class='btn btn-danger'>Eliminar</button>
            </div>
          </th></tr>";
        }
    $codTable .= "</table>" ;
    echo $codTable;
} else {
    echo "0 resultados";
}
$conn->close();
?>