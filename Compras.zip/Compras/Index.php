<html lang="es">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
  <meta name="generator" content="Jekyll v3.8.6">
  <title>Generación de Orden de Compra</title>

  <link rel="canonical" href="https://getbootstrap.com/docs/4.4/examples/checkout/">

  <!-- Bootstrap core CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
    integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
  <!-- Favicons -->
  <link rel="apple-touch-icon" href="/docs/4.4/assets/img/favicons/apple-touch-icon.png" sizes="180x180">
  <link rel="icon" href="/docs/4.4/assets/img/favicons/favicon-32x32.png" sizes="32x32" type="image/png">
  <link rel="icon" href="/docs/4.4/assets/img/favicons/favicon-16x16.png" sizes="16x16" type="image/png">
  <link rel="manifest" href="/docs/4.4/assets/img/favicons/manifest.json">
  <link rel="mask-icon" href="/docs/4.4/assets/img/favicons/safari-pinned-tab.svg" color="#563d7c">
  <link rel="icon" href="/docs/4.4/assets/img/favicons/favicon.ico">
  <meta name="msapplication-config" content="/docs/4.4/assets/img/favicons/browserconfig.xml">
  <meta name="theme-color" content="#563d7c">


  <style>
    table {
      font-family: arial, sans-serif;
      border-collapse: collapse;
      width: 100%;
    }

    td,
    th {
      border: 1px solid #dddddd;
      text-align: left;
      padding: 8px;
    }

    tr:nth-child(even) {
      background-color: #dddddd;
    }

    .bd-placeholder-img {
      font-size: 1.125rem;
      text-anchor: middle;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none;
    }

    @media (min-width: 768px) {
      .bd-placeholder-img-lg {
        font-size: 3.5rem;
      }
    }
  </style>
  <!-- Custom styles for this template -->
  <link href="form-validation.css" rel="stylesheet">
</head>

<body class="bg-light">

  <nav class="navbar navbar-expand-md navbar-dark bg-dark fixed-top mb-4">
    <a class="navbar-brand" href="#">Mi Trabajo</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault"
      aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarsExampleDefault">
      <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="View.php">Ordenes de Compra</a>
        </li>
      </ul>
    </div>
  </nav>
  <div class="container mt-4">
    <div class="py-5 text-center">
      <h2>Ordenes de Compra</h2>
    </div>
    <button type="button" onClick="ClearData()" class="btn btn-success" data-toggle="modal" data-target="#exampleModal">
  Crear OC
</button>
    <?php @include 'GenerateTable.php';?>

    <footer class="my-5 pt-5 text-muted text-center text-small">
      <p class="mb-1">© 2019 - TALLER DE PROGRAMACIÓN II</p>
    </footer>
  </div>

  <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Orden de Compra</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form class="needs-validation" action="insert.php" method="POST" novalidate="">
          <div class="row">
            <div class="col-md-4 mb-3">
              <label for="firstName">N° orden de Compra </label>
              <input type="text" class="form-control" name="NumeroCompra" id="NumeroCompra"
                placeholder="Ingrese numero de Compra" value="" required="">
              <div class="invalid-feedback">
                Valid first name is required.
              </div>
            </div>
            <div class="col-md-4 mb-3">
              <label for="lastName">Código articulo</label>
              <input type="text" class="form-control" name="Cod" id="Cod" placeholder="Ingrese codigo Articulo" value=""
                required="">
              <div class="invalid-feedback">
                Valid last name is required.
              </div>
            </div>
            <div class="col-md-4 mb-3">
              <label >Cantidad de artículos </label>
              <input type="number" class="form-control" name="Cant" id="Cant" placeholder="Ingrese Cantidad" value=""
                required="">
            </div>
          </div>
          <div class="mb-3">
            <label >Descripción del articulo </label>
            <textarea type="text" style="resize: none;" class="form-control" name="description" id="description" rows="4" cols="50"></textarea>
          </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" id="" class="btn btn-danger" data-dismiss="modal">Cerrar</button>
        <button type="button" id="Actualizar" class="btn btn-warning" onclick="UpdateOC();">Actualizar</button>
        <button type="button" id="Crear" onclick="CreateOC()" class="btn btn-success">Crear</button>
      </div>
    </div>
  </div>
</div>

<script src="https://code.jquery.com/jquery-3.4.1.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script src="compras.js"></script>
</body>

</html>