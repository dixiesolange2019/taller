function DeleteOC(value){
    $.ajax({
      url: 'delete.php',
      data:{NumeroCompra: value},
      method:"POST",
      success: function(respuesta) {
        location.reload();
      },
      error: function() {
            alert("No se ha podido obtener la información");
        }
    });
  }

  function GetDataOC(value){
    $.ajax({
      url: 'find.php',
      data:{orden: value},
      method:"POST",
      success: function(respuesta) {
        var obj = JSON.parse(respuesta);
        $("#NumeroCompra").val(obj.orden);
        $("#Cod").val(obj.codigoArticulo);
        $("#Cant").val(obj.cantidad);
        $("#description").val(obj.descripcionArticulo);
        $("#NumeroCompra").attr("disabled", true);
        $("#Actualizar").css("display", "block");
        $("#Crear").css("display", "none");
        $("#exampleModal").modal();
      },
      error: function() {
            alert("No se ha podido obtener la información");
        }
    });
  }

  function UpdateOC(){
    $.ajax({
      url: 'update.php',
      data:{
          NumeroCompra: $("#NumeroCompra").val(),
          Cod:$("#Cod").val(),
          Cant:$("#Cant").val(),
          description:$("#description").val()
        },
      method:"POST",
      success: function(respuesta) {
        location.reload();
      },
      error: function() {
            alert("No se ha podido obtener la información");
        }
    });
  }


  function CreateOC(){
    $.ajax({
      url: 'insert.php',
      data:{
          NumeroCompra: $("#NumeroCompra").val(),
          Cod:$("#Cod").val(),
          Cant:$("#Cant").val(),
          description:$("#description").val()
        },
      method:"POST",
      success: function(respuesta) {
        location.reload();
      },
      error: function() {
            alert("No se ha podido crear la OC");
        }
    });
  }


  function ClearData(){
    $("#NumeroCompra").val("");
    $("#Cod").val("");
    $("#Cant").val("");
    $("#description").val("");
    $("#NumeroCompra").attr("disabled", false);
    $("#Actualizar").css("display", "none");
    $("#Crear").css("display", "block");
  }

