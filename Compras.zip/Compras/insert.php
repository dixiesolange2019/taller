<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "comprasdfernandez";

$_NumeroCompra = $_POST["NumeroCompra"];
$_Cod = $_POST["Cod"];
$_Cant = $_POST["Cant"];
$_description = $_POST["description"];


$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO compras (orden, codigoArticulo, descripcionArticulo, cantidad) VALUES ( $_NumeroCompra, $_Cod,'$_description', $_Cant)";

if ($conn->query($sql) === TRUE) {
    echo "NUMERO DE OC:" . $_NumeroCompra;
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>