<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "comprasdfernandez";

$_NumeroCompra = $_POST["NumeroCompra"];
$_Cod = $_POST["Cod"];
$_Cant = $_POST["Cant"];
$_description = $_POST["description"];


$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "UPDATE compras SET codigoArticulo = $_Cod, descripcionArticulo = '$_description', 
        cantidad = $_Cant WHERE  orden = $_NumeroCompra";

if ($conn->query($sql) === TRUE) {
    echo "EL REGISTRO FUE ACTUALIZADO SATISFACTORIAMENTE";
} else {
    echo "Error deleting record: " . $conn->error;
}

$conn->close();
?>