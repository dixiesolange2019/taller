<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "comprasdfernandez";

$_NumeroCompra = $_POST["NumeroCompra"];

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "DELETE FROM compras WHERE  orden = $_NumeroCompra";

if ($conn->query($sql) === TRUE) {
    echo "EL REGISTRO FUE ELIMINADO SATISFACTORIAMENTE";
} else {
    echo "Error deleting record: " . $conn->error;
}

$conn->close();
?>