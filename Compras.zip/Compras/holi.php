<?php
    echo $_POST["firstname"];
?>